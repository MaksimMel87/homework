public class Main {
    // Проект 1
    public static void main(String[] args) {
        byte b = 1;
        short a = b;
        int c = a;
        long d = c;
        double e = d;

        System.out.println(b);
        System.out.println(a);
        System.out.println(c);
        System.out.println(d);
        System.out.println(e);

        //Проект 2
        long lo = 1000L;
        byte b1 = (byte) lo;
        short s1 = b1;
        int i1 = s1;
        double d1 = i1;

        System.out.println(lo);
        System.out.println(b1);
        System.out.println(s1);
        System.out.println(i1);
        System.out.println(d1);

        //Проект 3
        String st = "I study Basic Java!";
        char simb = st.charAt(0);
        char simb2 = st.charAt(18);
        System.out.println("Первый символ строки - " + simb);
        System.out.println("Последний символ строки - " + simb2);
        System.out.println("Строка содержит подстроку 'Java': " + st.contains("Java"));
        System.out.print("Замена букв: ");
        System.out.println(st.replace('a', 'o'));
        System.out.print("приведение к верхнему регистру: ");
        System.out.println(st.toUpperCase());
        System.out.print("приведение к нижнему регистру: ");
        System.out.println(st.toLowerCase());
        System.out.print("Вырезка: ");
        System.out.println(st.substring(0,13));

    }
}