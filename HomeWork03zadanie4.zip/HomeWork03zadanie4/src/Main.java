public class Main {
    public static void main(String[] args) {
        int i1 = 4;
        int i2 = 6;
        long l1 = 8;
        long l2 = 12;
        double d1 = 24;
        double d2 = 35;
        float f1 = 15;
        float f2 = 45;

        int решение1 = i1 + i2;
        long решение2 = l1 + l2;
        long решение3 = i1 + l1;
        float решение4 = i1 + f1;
        double решение5 = i1 + d1;
        double решение6 = l1 + d1;
        System.out.println(решение1);
        System.out.println(решение2);
        System.out.println(решение3);
        System.out.println(решение4);
        System.out.println(решение5);
        System.out.println(решение6);

    }
}