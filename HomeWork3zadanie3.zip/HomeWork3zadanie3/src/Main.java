public class Main {
    public static void main(String[] args) {
        System.out.println(5 % 4);
        System.out.println(15 % 3);
        boolean a = 2 % 2 == 0;
        System.out.println("true четное, false не четное: " + a);

        boolean b = 7 % 2 == 0;
        System.out.println("true четное, false не четное: " + b);

        boolean c = 13 % 2 == 0;
        System.out.println("true четное, false не четное: " + c);

        boolean d = 14 % 2 == 0;
        System.out.println("true четное, false не четное: " + d);

        int y1 = 25 % 10;
        System.out.println(y1);



    }
}