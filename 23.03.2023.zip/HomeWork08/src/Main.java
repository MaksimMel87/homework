import java.io.InputStream;
import java.util.Collections;
import java.util.Random;
import java.util.Scanner;

public class Main {
    //1 Пользователь вводит число. Если число больше 0, то выполнить следующие операции:
    //умножить число на 2, если оно нечётное;
    //прибавить к числу 5, если если оно заканчивается на 5 или 0.
    //Если число < 0, то взять его по модулю и разделить на 3.
    //Результат вычисления вывести в консоль.
    public static void main(String[] args) {
        System.out.println("Введите число: ");
        Scanner scr = new Scanner(System.in);
        int num = scr.nextInt();
        int lastNumber = num % 10;
        if (num > 0 && num % 2 != 0) {
            System.out.println(num * 2);
            if ((lastNumber == 5) | (lastNumber == 0))
                System.out.println(num + 5);
        }
        if (num < 0)
        {
            System.out.println(Math.abs(num)/3);
        }
        //2 Пользователь вводит строку. Если строка начинается с цифры (0, 1, 2, 3, 4, 5, 6 , 7, 8, 9), то вывести эту цифру в консоль.
        // Если строка начинается со знака _ или знака -, то вывести в консоль строку без этого знака.
        // Используйте методы startsWith, charAt и substring.
        System.out.println("Введи строку: ");
        String str = scr.next();
        char at = str.charAt(0);
        if (at=='0'|| at=='1'|| at=='2'|| at=='3'|| at=='4'|| at=='5'|| at=='6'||at=='7'|| at=='8'|| at==9) {
            System.out.println(at);
        }
        if (str.startsWith("_") || str.startsWith("-")) {
            System.out.println(str.substring(1));
        }
        //3 Пользователь вводит два числа. Если они не равны, то вывести в консоль их сумму,
        // иначе вывести их произведение.
        // Используйте тернарный оператор.

        System.out.println("Введите два числа: ");
        int number1 = scr.nextInt();
        int number2 = scr.nextInt();
            System.out.println(number1 != number2 ? number1 + number2 : number1 * number2);

        //4 С помощью Random сгенерируйте три числа.
        //Напишите программу, которая находит максимальное из них.
        //Используйте тернарные операторы.
        System.out.println();
        Random random = new Random();
        int a = random.nextInt();
        int b = random.nextInt();
        int c = random.nextInt();
        System.out.println(a > b ? (a > c ? a : c) : (b > c ? b : c));









        }





}


