public class Main {
    static final char yes = 'y';
    static final char no = 'n';
    public static void main(String[] args) {
        boolean Maxbool = true;
        byte Maxbyte = 3;
        short Maxshort = 180;
        int Maxint = 252525;
        long Maxlong = 34343434l;
        float Maxfloat = 15.4f;
        double Maxdouble = 14.43;
        char Maxchar = yes ;
        System.out.println("Maxbool:" + Maxbool);
        System.out.println("Maxbyte:" + Maxbyte);
        System.out.println("Maxshort:" + Maxshort);
        System.out.println("Maxint:" + Maxint);
        System.out.println("Maxlong:" + Maxlong);
        System.out.println("Maxfloat:" + Maxfloat);
        System.out.println("Maxdouble:" + Maxdouble);
        System.out.println("Maxchar:" + Maxchar);

        Maxint = Maxint / 7;
        System.out.println("Maxint:" + Maxint);
        Maxchar = no;
        System.out.println("Maxchar:" +Maxchar);
        Maxbool = false;
        System.out.println("Maxbool:" + Maxbool);



    }
}