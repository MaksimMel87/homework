public class Main {
    public static void main(String[] args) {
        String s = concat("ст 1", "ст 2","ст 3","|");
        System.out.println(s);
        char simb = s.charAt(0);
        System.out.println(simb);

}
    private static String concat(String s1, String s2, String s3, String delimiter) {
        return s1 + delimiter + s2 + delimiter + s3;

    }

}