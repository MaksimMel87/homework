import java.util.Random;
import java.util.Scanner;

public class Main { //1 Пользователь вводит трёхзначное число.
    // 2 Программа должна вывести на экран все цифры этого числа.
    // Какждая цифра должна быть выведена в отдельной строчке.
    public static void main(String[] args) {
        Scanner scaner = new Scanner(System.in);
        System.out.print("Ползователь вводит число: ");
        int a = scaner.nextInt();
        System.out.println(a / 100);
        System.out.println(a / 10 % 10);
        System.out.println(a % 10);
//
        Random random = new Random();
        int b = random.nextInt(999);
        long c = random.nextLong(999);
        int d = random.nextInt(999);
        System.out.println("Значения = " + b);
        System.out.println("Значения = " + c);
        System.out.println("Значения = " + d);
        System.out.println("Сумма " + ( b + c + d));
        System.out.println("Произведение "+ b * c * d);
    }
}