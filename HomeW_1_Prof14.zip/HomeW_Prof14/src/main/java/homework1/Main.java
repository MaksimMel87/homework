package homework1;

public class Main {
    public static void main(String[] args) {
        Person person1 = new Person();
        person1.setFullName("Кузя");
        person1.setAge(15);
        person1.move();
        person1.talk();


        Person person2 = new Person("Петя", 18);
        person2.move();
        person2.talk();
    }
}