package homework2;

public class Main {
    public static void main(String[] args) {
    Phone phone1 = new Phone();
    phone1.setModel("Huawai");
    phone1.setNumber("+111111111");
    phone1.setWeight(170.0);
    System.out.println("Модель: " + phone1.getModel());
    System.out.println("Номер: " + phone1.getNumber());
    System.out.println("Вес: " + phone1.getWeight());
    phone1.receiveCall("Петя");

    Phone phone2 = new Phone();
    phone2.setModel("Samsung");
    phone2.setNumber("+222222222");
    phone2.setWeight(180.0);
    System.out.println("Модель: " + phone2.getModel());
    System.out.println("Номер: " + phone2.getNumber());
    System.out.println("Вес: " + phone2.getWeight());
    phone2.receiveCall("Вася");

    Phone phone3 = new Phone();
    phone3.setModel("iPhone");
    phone3.setNumber("+333333333");
    phone3.setWeight(190.0);
    System.out.println("Модель: " + phone3.getModel());
    System.out.println("Номер: " + phone3.getNumber());
    System.out.println("Вес: " + phone3.getWeight());
    phone3.receiveCall("Коля");
}

}
