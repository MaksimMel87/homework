public class Main {
    public static void main(String[] args) {
        System.out.println("Буханкин Иван Петрович");
        System.out.println("Возвраст 65" );
        System.out.println("Рост 165");
        System.out.println();
        System.out.println("Бодров Сергей Сергеевич");
        System.out.println("Возвраст 52");
        System.out.println("Рост 176");
        System.out.println();
        System.out.println("Антоник Владимир Владимирович");
        System.out.println("Возвраст 70");
        System.out.println("Рост 170");
        System.out.println();
        System.out.printf("%.2f, %.2f, %.2f", 3.222 , 4.333, 5.444 );
        System.out.println();
        System.out.print(",");
        System.out.print("_");
        System.out.print("_");
        System.out.print("_");
        System.out.print("_");
        System.out.print("_");
        System.out.print("_");
        System.out.print("_");
        System.out.print("_");
        System.out.print(",");
        System.out.println();
        System.out.print("|");
        System.out.print("_");
        System.out.print("_");
        System.out.print("_");
        System.out.print("_");
        System.out.print("_");
        System.out.print("_");
        System.out.print("_");
        System.out.print("_");
        System.out.println("|");
    }
}