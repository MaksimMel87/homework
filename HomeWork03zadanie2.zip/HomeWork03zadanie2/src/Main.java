public class Main {
    public static void main(String[] args) {
        int Mihail = 51;
        int Petr = 20;
        int slozenie = Mihail + Petr;
        System.out.println("получилось:" + slozenie);

        int vichitanie = Mihail - Petr;
        System.out.println("получилось:" + vichitanie);

        int umnozenie = Mihail * Petr;
        System.out.println("получилось:" + umnozenie);

        int delenie = Mihail / Petr;
        System.out.println("получилось:" + delenie);

        int delenieost = Mihail % Petr;
        System.out.println("получилось с остатком:" + delenieost);





    }
}